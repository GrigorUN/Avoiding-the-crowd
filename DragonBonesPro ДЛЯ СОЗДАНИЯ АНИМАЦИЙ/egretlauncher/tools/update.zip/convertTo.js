#! /usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs-extra");
var path = require("path");
var commander = require("commander");
var object = require("./common/object");
var nodeUtils = require("./common/nodeUtils");
var dbft = require("./format/dragonBonesFormat");
var spft = require("./format/spineFormat");
var dbUtils = require("./format/utils");
var toFormat_1 = require("./action/toFormat");
var toV45_1 = require("./action/toV45");
var toNew_1 = require("./action/toNew");
var toBinary_1 = require("./action/toBinary");
var toWeb_1 = require("./action/toWeb");
var toSpine_1 = require("./action/toSpine");
var formatFormat_1 = require("./action/formatFormat");
function execute() {
    var commands = commander
        .version("0.0.51")
        .option("-i, --input [path]", "Input path")
        .option("-o, --output [path]", "Output path")
        .option("-t, --type [type]", "Convert to type [binary, new, v45, player, viewer, spine]", /^(binary|new|v45|player|viewer|spine|none)$/i, "none")
        .option("-f, --filter [keyword]", "Filter")
        .option("-d, --delete", "Delete raw files after convert complete")
        .parse(process.argv);
    var input = path.resolve(commands["input"] || process.cwd());
    var output = commands["output"] ? path.resolve(commands["output"] || "") : null;
    var type = commands["type"] || "";
    var filter = commands["filter"] || "";
    var deleteRaw = commands["delete"] || false;
    var loadTextureAtlasToData = false;
    var megreTextureAtlasToData = false;
    switch (type) {
        case "binary":
            break;
        case "new":
            if (!output) {
            }
            break;
        case "v45":
            if (!output) {
            }
            break;
        case "player":
        case "viewer":
            loadTextureAtlasToData = true;
            megreTextureAtlasToData = true;
            break;
        case "spine":
            loadTextureAtlasToData = true;
            megreTextureAtlasToData = true;
            break;
        default:
            console.log("Unknown type: " + type);
            return;
    }
    var files = nodeUtils.filterFileList(input, /\.(json)$/i);
    var _loop_1 = function (file) {
        if (filter && file.indexOf(filter) < 0) {
            return "continue";
        }
        var fileString = fs.readFileSync(file, "utf-8");
        var textureAtlasFiles = null;
        var textureAtlasImages = null;
        var textureAtlases = null;
        var dragonBonesData = toFormat_1.default(fileString, function () {
            textureAtlasFiles = dbUtils.getTextureAtlases(file);
            textureAtlases = textureAtlasFiles.map(function (v) {
                return getTextureAtlas(v);
            });
            return textureAtlases;
        });
        if (!dragonBonesData) {
            return "continue";
        }
        if (dragonBonesData.textureAtlas.length > 0) {
            textureAtlasFiles = null;
            textureAtlasImages = dragonBonesData.textureAtlas.map(function (v) {
                return v.imagePath;
            });
            textureAtlases = dragonBonesData.textureAtlas;
        }
        else {
            if (!textureAtlasFiles) {
                textureAtlasFiles = dbUtils.getTextureAtlases(file);
            }
            textureAtlasImages = textureAtlasFiles.map(function (v) {
                return v.replace(".json", ".png");
            });
            if (loadTextureAtlasToData && textureAtlasFiles.length > 0) {
                textureAtlases = textureAtlasFiles.map(function (v) {
                    return getTextureAtlas(v);
                });
            }
        }
        if (megreTextureAtlasToData && textureAtlases && dragonBonesData.textureAtlas.length === 0) {
            for (var _i = 0, textureAtlases_1 = textureAtlases; _i < textureAtlases_1.length; _i++) {
                var textureAtals = textureAtlases_1[_i];
                dragonBonesData.textureAtlas.push(textureAtals);
            }
            textureAtlases = dragonBonesData.textureAtlas;
        }
        switch (type) {
            case "binary": {
                toNew_1.default(dragonBonesData, true);
                formatFormat_1.default(dragonBonesData);
                var result = toBinary_1.default(dragonBonesData);
                var outputFile = (output ? file.replace(input, output) : file).replace(".json", ".dbbin");
                if (!fs.existsSync(path.dirname(outputFile))) {
                    fs.mkdirsSync(path.dirname(outputFile));
                }
                fs.writeFileSync(outputFile, new Buffer(result));
                console.log(outputFile);
                if (deleteRaw && output) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _a = 0, textureAtlasFiles_1 = textureAtlasFiles; _a < textureAtlasFiles_1.length; _a++) {
                            var textureAtlasFile = textureAtlasFiles_1[_a];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                            else {
                                var outputFile_1 = textureAtlasFile.replace(input, output);
                                fs.moveSync(textureAtlasFile, outputFile_1);
                                console.log(outputFile_1);
                            }
                        }
                    }
                    for (var _b = 0, textureAtlasImages_1 = textureAtlasImages; _b < textureAtlasImages_1.length; _b++) {
                        var textureAtlasImage = textureAtlasImages_1[_b];
                        var outputFile_2 = textureAtlasImage.replace(input, output);
                        fs.moveSync(textureAtlasImage, outputFile_2);
                        console.log(outputFile_2);
                    }
                }
                else if (deleteRaw) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _c = 0, textureAtlasFiles_2 = textureAtlasFiles; _c < textureAtlasFiles_2.length; _c++) {
                            var textureAtlasFile = textureAtlasFiles_2[_c];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                        }
                    }
                }
                else if (output) {
                    if (textureAtlasFiles && !megreTextureAtlasToData) {
                        for (var _d = 0, textureAtlasFiles_3 = textureAtlasFiles; _d < textureAtlasFiles_3.length; _d++) {
                            var textureAtlasFile = textureAtlasFiles_3[_d];
                            var outputFile_3 = textureAtlasFile.replace(input, output);
                            fs.copySync(textureAtlasFile, outputFile_3);
                            console.log(outputFile_3);
                        }
                    }
                    for (var _e = 0, textureAtlasImages_2 = textureAtlasImages; _e < textureAtlasImages_2.length; _e++) {
                        var textureAtlasImage = textureAtlasImages_2[_e];
                        var outputFile_4 = textureAtlasImage.replace(input, output);
                        fs.copySync(textureAtlasImage, outputFile_4);
                        console.log(outputFile_4);
                    }
                }
                break;
            }
            case "new": {
                toNew_1.default(dragonBonesData, false);
                formatFormat_1.default(dragonBonesData);
                object.compress(dragonBonesData, dbft.compressConfig);
                var result = JSON.stringify(dragonBonesData);
                var outputFile = output ? file.replace(input, output) : file;
                if (!fs.existsSync(path.dirname(outputFile))) {
                    fs.mkdirsSync(path.dirname(outputFile));
                }
                fs.writeFileSync(outputFile, result);
                console.log(outputFile);
                if (deleteRaw && output) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _f = 0, textureAtlasFiles_4 = textureAtlasFiles; _f < textureAtlasFiles_4.length; _f++) {
                            var textureAtlasFile = textureAtlasFiles_4[_f];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                            else {
                                var outputFile_5 = textureAtlasFile.replace(input, output);
                                fs.moveSync(textureAtlasFile, outputFile_5);
                                console.log(outputFile_5);
                            }
                        }
                    }
                    for (var _g = 0, textureAtlasImages_3 = textureAtlasImages; _g < textureAtlasImages_3.length; _g++) {
                        var textureAtlasImage = textureAtlasImages_3[_g];
                        var outputFile_6 = textureAtlasImage.replace(input, output);
                        fs.moveSync(textureAtlasImage, outputFile_6);
                        console.log(outputFile_6);
                    }
                }
                else if (deleteRaw) {
                    if (textureAtlasFiles) {
                        for (var _h = 0, textureAtlasFiles_5 = textureAtlasFiles; _h < textureAtlasFiles_5.length; _h++) {
                            var textureAtlasFile = textureAtlasFiles_5[_h];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                        }
                    }
                }
                else if (output) {
                    if (textureAtlasFiles && !megreTextureAtlasToData) {
                        for (var _j = 0, textureAtlasFiles_6 = textureAtlasFiles; _j < textureAtlasFiles_6.length; _j++) {
                            var textureAtlasFile = textureAtlasFiles_6[_j];
                            var outputFile_7 = textureAtlasFile.replace(input, output);
                            fs.copySync(textureAtlasFile, outputFile_7);
                            console.log(outputFile_7);
                        }
                    }
                    for (var _k = 0, textureAtlasImages_4 = textureAtlasImages; _k < textureAtlasImages_4.length; _k++) {
                        var textureAtlasImage = textureAtlasImages_4[_k];
                        var outputFile_8 = textureAtlasImage.replace(input, output);
                        fs.copySync(textureAtlasImage, outputFile_8);
                        console.log(outputFile_8);
                    }
                }
                break;
            }
            case "v45": {
                toV45_1.default(dragonBonesData);
                formatFormat_1.default(dragonBonesData);
                object.compress(dragonBonesData, dbft.compressConfig);
                var result = JSON.stringify(dragonBonesData);
                var outputFile = output ? file.replace(input, output) : file;
                if (!fs.existsSync(path.dirname(outputFile))) {
                    fs.mkdirsSync(path.dirname(outputFile));
                }
                fs.writeFileSync(outputFile, result);
                console.log(outputFile);
                if (deleteRaw && output) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _l = 0, textureAtlasFiles_7 = textureAtlasFiles; _l < textureAtlasFiles_7.length; _l++) {
                            var textureAtlasFile = textureAtlasFiles_7[_l];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                            else {
                                var outputFile_9 = textureAtlasFile.replace(input, output);
                                fs.moveSync(textureAtlasFile, outputFile_9);
                                console.log(outputFile_9);
                            }
                        }
                    }
                    for (var _m = 0, textureAtlasImages_5 = textureAtlasImages; _m < textureAtlasImages_5.length; _m++) {
                        var textureAtlasImage = textureAtlasImages_5[_m];
                        var outputFile_10 = textureAtlasImage.replace(input, output);
                        fs.moveSync(textureAtlasImage, outputFile_10);
                        console.log(outputFile_10);
                    }
                }
                else if (deleteRaw) {
                    if (textureAtlasFiles) {
                        for (var _o = 0, textureAtlasFiles_8 = textureAtlasFiles; _o < textureAtlasFiles_8.length; _o++) {
                            var textureAtlasFile = textureAtlasFiles_8[_o];
                            if (megreTextureAtlasToData) {
                                fs.removeSync(textureAtlasFile);
                            }
                        }
                    }
                }
                else if (output) {
                    if (textureAtlasFiles && !megreTextureAtlasToData) {
                        for (var _p = 0, textureAtlasFiles_9 = textureAtlasFiles; _p < textureAtlasFiles_9.length; _p++) {
                            var textureAtlasFile = textureAtlasFiles_9[_p];
                            var outputFile_11 = textureAtlasFile.replace(input, output);
                            fs.copySync(textureAtlasFile, outputFile_11);
                            console.log(outputFile_11);
                        }
                    }
                    for (var _q = 0, textureAtlasImages_6 = textureAtlasImages; _q < textureAtlasImages_6.length; _q++) {
                        var textureAtlasImage = textureAtlasImages_6[_q];
                        var outputFile_12 = textureAtlasImage.replace(input, output);
                        fs.copySync(textureAtlasImage, outputFile_12);
                        console.log(outputFile_12);
                    }
                }
                break;
            }
            case "player":
            case "viewer": {
                toNew_1.default(dragonBonesData, true);
                formatFormat_1.default(dragonBonesData);
                var result = toWeb_1.default({
                    data: new Buffer(toBinary_1.default(dragonBonesData)),
                    textureAtlases: textureAtlasImages.map(function (v) {
                        if (fs.existsSync(v)) {
                            return fs.readFileSync(v);
                        }
                        return null;
                    }),
                    config: {
                        isLocal: true
                    }
                }, type === "player");
                var outputFile = (output ? file.replace(input, output) : file).replace(".json", ".html");
                if (!fs.existsSync(path.dirname(outputFile))) {
                    fs.mkdirsSync(path.dirname(outputFile));
                }
                fs.writeFileSync(outputFile, new Buffer(result));
                console.log(outputFile);
                if (deleteRaw) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _r = 0, textureAtlasFiles_10 = textureAtlasFiles; _r < textureAtlasFiles_10.length; _r++) {
                            var textureAtlasFile = textureAtlasFiles_10[_r];
                            fs.removeSync(textureAtlasFile);
                        }
                    }
                    for (var _s = 0, textureAtlasImages_7 = textureAtlasImages; _s < textureAtlasImages_7.length; _s++) {
                        var textureAtlasImage = textureAtlasImages_7[_s];
                        fs.removeSync(textureAtlasImage);
                    }
                }
                break;
            }
            case "spine": {
                toNew_1.default(dragonBonesData, true);
                formatFormat_1.default(dragonBonesData);
                var result = toSpine_1.default(dragonBonesData, "3.6.0", !output);
                var base = (output ? file.replace(input, output) : file).replace("_ske.json", "");
                dragonBonesData.name = path.basename(base); // Modify name to file name.
                console.log(dragonBonesData.name);
                for (var _t = 0, _u = result.spines; _t < _u.length; _t++) {
                    var spine = _u[_t];
                    object.compress(spine, spft.compressConfig);
                    var outputFile_13 = (result.spines.length > 1 ? base + "_" + spine.skeleton.name : base) + (output ? ".json" : "_spine.json");
                    delete spine.skeleton.name; // delete keep name.
                    if (!fs.existsSync(path.dirname(outputFile_13))) {
                        fs.mkdirsSync(path.dirname(outputFile_13));
                    }
                    fs.writeFileSync(outputFile_13, JSON.stringify(spine));
                    console.log(outputFile_13);
                }
                var outputFile = base + (output ? ".atlas" : "_spine.atlas");
                if (!fs.existsSync(path.dirname(outputFile))) {
                    fs.mkdirsSync(path.dirname(outputFile));
                }
                fs.writeFileSync(outputFile, result.textureAtlas);
                console.log(outputFile);
                if (deleteRaw) {
                    fs.unlinkSync(file);
                    if (textureAtlasFiles) {
                        for (var _v = 0, textureAtlasFiles_11 = textureAtlasFiles; _v < textureAtlasFiles_11.length; _v++) {
                            var textureAtlasFile = textureAtlasFiles_11[_v];
                            fs.removeSync(textureAtlasFile);
                        }
                    }
                }
                var index = 0;
                for (var _w = 0, textureAtlasImages_8 = textureAtlasImages; _w < textureAtlasImages_8.length; _w++) {
                    var textureAtlasImage = textureAtlasImages_8[_w];
                    if (fs.existsSync(textureAtlasImage)) {
                        var outputFile_14 = path.join(path.dirname(output ? textureAtlasImage.replace(input, output) : textureAtlasImage), dragonBonesData.name + (output ? "" : "_spine") + (textureAtlasImages.length > 1 ? "_" + index : "") + ".png");
                        if (deleteRaw) {
                            fs.moveSync(textureAtlasImage, outputFile_14);
                        }
                        else {
                            fs.copySync(textureAtlasImage, outputFile_14);
                        }
                        console.log(outputFile_14);
                    }
                    index++;
                }
                break;
            }
            default:
                break;
        }
    };
    for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
        var file = files_1[_i];
        _loop_1(file);
    }
    console.log("Convert complete.");
}
function getTextureAtlas(textureAtlasFile) {
    var textureAtlas = new dbft.TextureAtlas();
    object.copyObjectFrom(JSON.parse(fs.readFileSync(textureAtlasFile, "utf-8")), textureAtlas, dbft.copyConfig);
    return textureAtlas;
}
execute();
