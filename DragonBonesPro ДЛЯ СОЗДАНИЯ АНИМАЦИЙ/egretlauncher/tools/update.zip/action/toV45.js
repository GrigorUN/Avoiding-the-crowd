"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var dbft = require("../format/dragonBonesFormat");
function default_1(data) {
    data.version = dbft.DATA_VERSION_4_5;
    data.compatibleVersion = dbft.DATA_VERSION_4_0;
    for (var _i = 0, _a = data.armature; _i < _a.length; _i++) {
        var armature = _a[_i];
        if (armature.defaultActions.length > 0) {
            for (var i = 0, l = armature.defaultActions.length; i < l; ++i) {
                var action = armature.defaultActions[i];
                if (action instanceof dbft.Action) {
                    var oldAction = new dbft.OldAction();
                    oldAction.gotoAndPlay = action.name;
                    armature.defaultActions[i] = oldAction;
                }
            }
        }
        // if (forRuntime) {
        //     for (const slot of armature.slot) {
        //         if (slot.actions.length > 0) {
        //             const defaultSkin = armature.getSkin("default");
        //             if (defaultSkin) {
        //                 const skinSlot = defaultSkin.getSlot(slot.name);
        //                 if (skinSlot !== null && skinSlot instanceof dbft.SkinSlot) {
        //                     for (const action of slot.actions) {
        //                         if (action instanceof dbft.OldAction) {
        //                             for (const display of skinSlot.display) {
        //                                 if (display instanceof dbft.ArmatureDisplay) {
        //                                     display.actions.push(dbft.oldActionToNewAction(action));
        //                                 }
        //                             }
        //                         }
        //                     }
        //                 }
        //             }
        //             slot.actions.length = 0;
        //         }
        //     }
        // }
        for (var _b = 0, _c = armature.animation; _b < _c.length; _b++) {
            var animation = _c[_b];
            for (var _d = 0, _e = animation.frame; _d < _e.length; _d++) {
                var frame = _e[_d];
                if (frame.events.length > 0) {
                    var events = [];
                    var i = frame.events.length;
                    while (i--) {
                        var action = frame.events[i];
                        switch (action.type) {
                            case dbft.ActionType.Play:
                                frame.action = action.name;
                                break;
                            case dbft.ActionType.Sound:
                                frame.sound = action.name;
                                break;
                            case dbft.ActionType.Frame:
                                if (frame.event) {
                                    events.push(action);
                                }
                                else {
                                    frame.event = action.name;
                                }
                                break;
                        }
                    }
                    frame.events.length = 0;
                    if (events.length > 0) {
                        for (var _f = 0, events_1 = events; _f < events_1.length; _f++) {
                            var action = events_1[_f];
                            frame.events.push(action);
                        }
                    }
                }
                else {
                    var i = frame.actions.length;
                    while (i--) {
                        var action = frame.actions[i];
                        switch (action.type) {
                            case dbft.ActionType.Play:
                                frame.action = action.name;
                                break;
                            case dbft.ActionType.Sound:
                                frame.sound = action.name;
                                break;
                            case dbft.ActionType.Frame:
                                if (frame.event) {
                                    frame.events.push(action);
                                }
                                else {
                                    frame.event = action.name;
                                }
                                break;
                        }
                    }
                    frame.actions.length = 0;
                }
            }
            var position = 0;
            for (var _g = 0, _h = animation.bone; _g < _h.length; _g++) {
                var timeline = _h[_g];
                for (var _j = 0, _k = timeline.rotateFrame; _j < _k.length; _j++) {
                    var rotateFrame = _k[_j];
                    var frame = new dbft.BoneAllFrame();
                    frame.duration = rotateFrame.duration;
                    frame.tweenEasing = rotateFrame.tweenEasing;
                    frame.curve = rotateFrame.curve;
                    frame.tweenRotate = rotateFrame.clockwise;
                    frame.transform.skX = rotateFrame.rotate + rotateFrame.skew;
                    frame.transform.skY = rotateFrame.rotate;
                    timeline.frame.push(frame);
                }
                if (timeline.frame.length === 0) {
                    var frame = new dbft.BoneAllFrame();
                    frame.duration = animation.duration;
                    timeline.frame.push(frame);
                }
                position = 0;
                for (var _l = 0, _m = timeline.translateFrame; _l < _m.length; _l++) {
                    var translateFrame = _m[_l];
                    var index = timeline.insertFrame(timeline.frame, position);
                    if (index >= 0) {
                        for (var i = index; i < timeline.frame.length; ++i) {
                            var frame = timeline.frame[i];
                            frame.transform.x = translateFrame.x;
                            frame.transform.y = translateFrame.y;
                        }
                        var insertFrame = timeline.frame[index];
                        if (translateFrame.getTweenEnabled() && !insertFrame.getTweenEnabled()) {
                            insertFrame.tweenEasing = translateFrame.tweenEasing;
                            insertFrame.curve = translateFrame.curve;
                        }
                    }
                    position += translateFrame.duration;
                }
                position = 0;
                for (var _o = 0, _p = timeline.scaleFrame; _o < _p.length; _o++) {
                    var scaleFrame = _p[_o];
                    var index = timeline.insertFrame(timeline.frame, position);
                    if (index >= 0) {
                        for (var i = index; i < timeline.frame.length; ++i) {
                            var frame = timeline.frame[i];
                            frame.transform.scX = scaleFrame.x;
                            frame.transform.scY = scaleFrame.y;
                        }
                        var insertFrame = timeline.frame[index];
                        if (scaleFrame.getTweenEnabled() && !insertFrame.getTweenEnabled()) {
                            insertFrame.tweenEasing = scaleFrame.tweenEasing;
                            insertFrame.curve = scaleFrame.curve;
                        }
                    }
                    position += scaleFrame.duration;
                }
                timeline.translateFrame.length = 0;
                timeline.rotateFrame.length = 0;
                timeline.scaleFrame.length = 0;
            }
            for (var _q = 0, _r = animation.slot; _q < _r.length; _q++) {
                var timeline = _r[_q];
                var slot = armature.getSlot(timeline.name);
                if (!slot) {
                    continue;
                }
                for (var _s = 0, _t = timeline.colorFrame; _s < _t.length; _s++) {
                    var colorFrame = _t[_s];
                    var frame = new dbft.SlotAllFrame();
                    frame.duration = colorFrame.duration;
                    frame.tweenEasing = colorFrame.tweenEasing;
                    frame.curve = colorFrame.curve;
                    frame.color.copyFrom(colorFrame.value);
                    timeline.frame.push(frame);
                }
                if (timeline.frame.length === 0) {
                    var frame = new dbft.SlotAllFrame();
                    frame.duration = animation.duration;
                    frame.displayIndex = slot.displayIndex;
                    frame.color.copyFrom(slot.color);
                    timeline.frame.push(frame);
                }
                position = 0;
                for (var _u = 0, _v = timeline.displayFrame; _u < _v.length; _u++) {
                    var displayFrame = _v[_u];
                    var index = timeline.insertFrame(timeline.frame, position);
                    if (index >= 0) {
                        for (var i = index; i < timeline.frame.length; ++i) {
                            var frame = timeline.frame[i];
                            frame.displayIndex = displayFrame.value;
                        }
                    }
                    position += displayFrame.duration;
                }
                timeline.displayFrame.length = 0;
                timeline.colorFrame.length = 0;
            }
        }
    }
    return data;
}
exports.default = default_1;
