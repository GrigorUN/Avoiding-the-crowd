"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function rgbaToHex(r, g, b, a) {
    var result = "";
    var s = Math.round(r).toString(16);
    if (s.length < 2)
        (s = "0" + s);
    result += s;
    s = Math.round(g).toString(16);
    if (s.length < 2)
        (s = "0" + s);
    result += s;
    s = Math.round(b).toString(16);
    if (s.length < 2)
        (s = "0" + s);
    result += s;
    s = Math.round(a).toString(16);
    if (s.length < 2)
        (s = "0" + s);
    result += s;
    return result;
}
exports.rgbaToHex = rgbaToHex;
function getEnumFormString(enumerator, type, defaultType) {
    if (defaultType === void 0) { defaultType = -1; }
    if (typeof type === "number") {
        return type;
    }
    for (var k in enumerator) {
        if (typeof k === "string") {
            if (k.toLowerCase() === type.toLowerCase()) {
                return enumerator[k];
            }
        }
    }
    return defaultType;
}
exports.getEnumFormString = getEnumFormString;
