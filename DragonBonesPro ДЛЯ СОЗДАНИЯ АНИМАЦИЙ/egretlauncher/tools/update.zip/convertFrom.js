#! /usr/bin/env node
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs = require("fs-extra");
var path = require("path");
var commander = require("commander");
var object = require("./common/object");
var nodeUtils = require("./common/nodeUtils");
var dbft = require("./format/dragonBonesFormat");
var spft = require("./format/spineFormat");
var fromSpine_1 = require("./action/fromSpine");
var formatFormat_1 = require("./action/formatFormat");
var helper = require("./helper/helperRemote");
function execute() {
    var commands = commander
        .version("0.0.51")
        .option("-i, --input [path]", "Input path")
        .option("-o, --output [path]", "Output path")
        .option("-t, --type [type]", "Convert from type [spine, cocos]", /^(spine|cocos)$/i, "none")
        .option("-f, --filter [keyword]", "Filter")
        .option("-d, --delete", "Delete raw files after convert complete.")
        .parse(process.argv);
    var input = path.resolve(commands["input"] || process.cwd());
    var output = path.resolve(commands["output"] || "");
    var type = commands["type"] || "";
    var filter = commands["filter"] || "";
    var deleteRaw = commands["delete"] || false;
    // let loadTextureAtlasToData = false;
    // let megreTextureAtlasToData = false;
    switch (type) {
        case "spine":
            {
                var files = nodeUtils.filterFileList(input, /\.(json)$/i);
                for (var _i = 0, files_1 = files; _i < files_1.length; _i++) {
                    var file = files_1[_i];
                    if (filter && file.indexOf(filter) < 0) {
                        continue;
                    }
                    var fileString = fs.readFileSync(file, "utf-8");
                    if (!spft.isSpineString(fileString)) {
                        continue;
                    }
                    var fileName = path.basename(file).replace(".json", "");
                    var textureAtlasFile = path.join(path.dirname(file), fileName + ".atlas");
                    var textureAtlasString = "";
                    if (fs.existsSync(textureAtlasFile)) {
                        textureAtlasString = fs.readFileSync(textureAtlasFile, "utf-8");
                    }
                    var spine = new spft.Spine();
                    object.copyObjectFrom(JSON.parse(fileString), spine, spft.copyConfig);
                    var result = fromSpine_1.default({ name: fileName, data: spine, textureAtlas: textureAtlasString });
                    var outputFile = (output ? file.replace(input, output) : file).replace(".json", "_ske.json");
                    formatFormat_1.default(result);
                    var textureAtlases = result.textureAtlas.concat(); // TODO
                    result.textureAtlas.length = 0;
                    object.compress(result, dbft.compressConfig);
                    if (!fs.existsSync(path.dirname(outputFile))) {
                        fs.mkdirsSync(path.dirname(outputFile));
                    }
                    fs.writeFileSync(outputFile, JSON.stringify(result));
                    console.log(outputFile);
                    if (deleteRaw) {
                        fs.removeSync(file);
                        fs.removeSync(textureAtlasFile);
                    }
                    var index = 0;
                    for (var _a = 0, textureAtlases_1 = textureAtlases; _a < textureAtlases_1.length; _a++) {
                        var textureAtlas = textureAtlases_1[_a];
                        var pageName = "_tex" + (textureAtlases.length > 1 ? index++ : "");
                        var outputFile_1 = (output ? file.replace(input, output) : file).replace(".json", pageName + ".json");
                        var textureAtlasImage = path.join(path.dirname(file), textureAtlas.imagePath);
                        textureAtlas.imagePath = path.basename(outputFile_1).replace(".json", ".png");
                        var imageOutputFile = path.join(path.dirname(outputFile_1), textureAtlas.imagePath);
                        if (!fs.existsSync(path.dirname(imageOutputFile))) {
                            fs.mkdirsSync(path.dirname(imageOutputFile));
                        }
                        object.compress(textureAtlas, dbft.compressConfig);
                        if (!fs.existsSync(path.dirname(outputFile_1))) {
                            fs.mkdirsSync(path.dirname(outputFile_1));
                        }
                        fs.writeFileSync(outputFile_1, JSON.stringify(textureAtlas));
                        var hasRotated = false;
                        for (var _b = 0, _c = textureAtlas.SubTexture; _b < _c.length; _b++) {
                            var texture = _c[_b];
                            if (texture.rotated) {
                                hasRotated = true;
                            }
                        }
                        if (deleteRaw) {
                            fs.moveSync(textureAtlasImage, imageOutputFile);
                        }
                        else {
                            fs.copySync(textureAtlasImage, imageOutputFile);
                        }
                        if (hasRotated) {
                            var input_1 = {
                                type: "modify_spine_textureatlas",
                                data: {
                                    file: imageOutputFile,
                                    config: textureAtlas,
                                    texture: fs.readFileSync(imageOutputFile, "base64")
                                }
                            };
                            helper.addInput(input_1);
                        }
                        console.log(outputFile_1);
                        console.log(imageOutputFile);
                    }
                }
                break;
            }
        case "cocos":
            // loadTextureAtlasToData = true;
            // megreTextureAtlasToData = true;
            break;
        default:
            console.log("Unknown type: " + type);
            return;
    }
    console.log("Convert complete.");
    if (helper.hasInput()) {
        helper.start();
        console.log("Waitting for helper.");
    }
}
execute();
